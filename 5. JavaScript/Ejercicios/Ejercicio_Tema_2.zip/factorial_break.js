const num = 10;
let i = 1;
let factorial = i;

while(num >= i++){
    if(i === 1){
        break;
    } else {
        factorial *= i;
    }
}

console.log("El factorial de 10: "+factorial)