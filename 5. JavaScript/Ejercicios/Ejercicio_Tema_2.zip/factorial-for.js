let factorial = 1;

for (let index = 1; index <= 10; index++) {
    factorial = factorial*index;  
}

console.log("El factorial de 10 es: " + factorial);