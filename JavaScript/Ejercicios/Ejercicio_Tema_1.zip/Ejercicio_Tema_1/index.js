const name = "Carlos Amaranto";
const age = 22;
const question = true;
const birthdate = new Date("June 4 2002");
const favorite_book = {
    name_book: "Brave New World",
    name_author: "Aldous Huxley",
    date: new Date("2, 1, 1932"),
    url: "https://en.wikipedia.org/wiki/Brave_New_World"
}

const Me = {
    name,
    age,
    question,
    birthdate,
    favorite_book
}

console.log(Me);